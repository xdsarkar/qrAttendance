<?php

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Attendance App</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
        <style>
            body, html {
                padding: 0;
                margin: 0;
                font-family: 'Helvetica Neue', 'Calibri', Arial, sans-serif;
                height: 100%;
            }
            #app {
                background: #263238;
                display: flex;
                align-items: stretch;
                justify-content: stretch;
                height: 100%;
            }
            .sidebar {
                background: #eceff1;
                min-width: 250px;
                display: flex;
                flex-direction: column;
                justify-content: flex-start;
                overflow: auto;
            }
            .preview-container {
                flex-direction: column;
                align-items: center;
                justify-content: center;
                display: flex;
                width: 100%;
                overflow: hidden;
            }
        </style>
    </head>
    <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Attendance App</a>
    </nav>
    <div id="app">
    <div class="sidebar">
    </div>
    <div class="preview-container">
        <video  id="preview"></video>
    </div>
    </div>
    </body>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="lib/instascan.min.js"></script>
    <script type="text/javascript">
        let scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
        scanner.addListener('scan', function (content) {
            $.ajax({
                url: '/controller.php',
                method: 'POST',
                data: {postBody: JSON.stringify({
                    email: content,
                })},
                dataType: 'json'
            }).done((res) => {
                console.log(res)
            }).fail((err) => {
                console.log(err)
            })
        });
        Instascan.Camera.getCameras().then(function (cameras) {
            if (cameras.length > 0) {
                scanner.start(cameras[0]);
            } else {
                console.error('No cameras found.');
            }
        }).catch(function (e) {
            console.error(e);
        });
    </script>
</html>