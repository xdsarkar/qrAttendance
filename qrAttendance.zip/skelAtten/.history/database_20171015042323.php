<?php
    $user = 'root';
    $password = 'root';
    $db = 'inventory';
    $servername = 'localhost:8889';

    $conn = mysqli_connect($servername, $user, $password);