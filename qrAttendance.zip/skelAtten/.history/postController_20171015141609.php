<?php

require 'config';

/*

Variable available

DB_HOST
DB_NAME
DB_USER
DB_PASS
DB_TABLE

*/

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

$decodedBody = json_decode($_POST['postBody'], true);

$email = trim($decodedBody['email']);

$query = "INSERT INTO dailyAttendanceTable (email) VALUES ('$email')";
error_log(print_r($query, true));

header("Content-type:application/json");
if ($conn->query($query) === TRUE) {
    $result = array(
        'email' => $email,
        'message' => 'Present'
    );
} else {
    $result = array(
        'email' => '',
        'message' => 'Something went wrong'
    );

    echo $conn->error;
}
$conn->close();
echo json_encode($result);


