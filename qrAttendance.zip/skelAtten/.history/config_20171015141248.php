<?php

define("DB_HOST", 'localhost:8999');
define("DB_NAME", '');
define("DB_USER", '');
define("DB_PASS", '');
define("DB_TABLE", '');