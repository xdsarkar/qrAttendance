<?php
    $user = 'root';
    $password = 'root';
    $db = 'inventory';
    $servername = 'localhost:8889';

    $conn = mysqli_connect($servername, $user, $password);
    $sql = "CREATE DATABASE myDB";
    if ($conn->query($sql) === TRUE) {
        echo "Database created successfully";
    } else {
        echo "Error creating database: " . $conn->error;
    }
    $conn->close();