<?php

define("DB_HOST", 'localhost:8999');
define("DB_NAME", 'attendanceApp');
define("DB_USER", 'root');
define("DB_PASS", 'root');
define("DB_TABLE", 'dailyAttendanceTable');