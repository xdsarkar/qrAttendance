<?php

define("DB_HOST", 'localhost:8999');
define("DB_NAME", 'attendanceApp');
define("DB_USER", 'root');
define("DB_PASS", '');
define("DB_TABLE", 'dailyAttendanceTable');